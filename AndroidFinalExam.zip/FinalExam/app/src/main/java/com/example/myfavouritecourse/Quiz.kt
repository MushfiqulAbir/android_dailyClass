package com.example.myfavouritecourse

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.RadioButton
import android.widget.RadioGroup
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_quiz.*
import kotlinx.android.synthetic.main.activity_quiz.view.*

class Quiz : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)

        //array to save checked correct answers
        val list: ArrayList<String>
        list = ArrayList()

        //initializing correct answers
        val groupOne = findViewById<RadioButton>(R.id.r1)
        val groupTwo = findViewById<RadioButton>(R.id.r4)
        val groupThree = findViewById<RadioButton>(R.id.r5)
        val groupFour = findViewById<RadioButton>(R.id.r7)
        val groupFive = findViewById<RadioButton>(R.id.r9)
        val groupSix = findViewById<RadioButton>(R.id.r11)


        //checking if the correct answer is checked or not
        groupOne.setOnClickListener() {
            if (r1.isChecked()) {
                list.add("1")
            } else {
                list.remove("1")
            }
        }

        groupTwo.setOnClickListener() {
            if (r4.isChecked()) {
                list.add("2")
            } else {
                list.remove("2")
            }
        }
        groupThree.setOnClickListener() {
            if (r5.isChecked()) {
                list.add("3")
            } else {
                list.remove("3")
            }
        }
        groupFour.setOnClickListener() {
            if (r7.isChecked()) {
                list.add("4")
            } else {
                list.remove("4")
            }
        }
        groupFive.setOnClickListener() {
            if (r9.isChecked()) {
                list.add("5")
            } else {
                list.remove("5")
            }
        }
        groupSix.setOnClickListener() {
            if (r11.isChecked()) {
                list.add("6")
            } else {
                list.remove("6")
            }
        }


        //checking list array value to give score
        submitButton.setOnClickListener {
            if (list.count() == 6) {
                scoreView.text = "Your Score Is: 6"
            } else if (list.count() == 5) {
                scoreView.text = "Your Score Is: 5"
            } else if (list.count() == 4) {
                scoreView.text = "Your Score Is: 4"
            } else if (list.count() == 3) {
                scoreView.text = "Your Score Is: 3"
            } else if (list.count() == 2) {
                scoreView.text = "Your Score Is: 2"
            } else if (list.count() == 1) {
                scoreView.text = "Your Score Is: 1"
            } else {
                scoreView.text = "Your Score Is: 0"
            }
        }

        //restart quiz button
        restartButton.setOnClickListener {
            val intent = Intent(this, Quiz::class.java)
            startActivity(intent)
        }

        //back to home button
        quizHome.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }



        }
    }