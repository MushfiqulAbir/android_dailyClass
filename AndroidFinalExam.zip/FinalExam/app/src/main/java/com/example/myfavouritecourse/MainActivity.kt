package com.example.myfavouritecourse

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import java.text.SimpleDateFormat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val date = System.currentTimeMillis()

        val sdf = SimpleDateFormat("MMM dd, yyyy h:mm a")
        val dateString: String = sdf.format(date)
        timeView.setText(dateString)


        //Syllabus activity button
        syllabusButton.setOnClickListener {
            val intent = Intent(this, Syllabus::class.java)
            startActivity(intent)
        }

        //Chapter activity button
        chapterButton.setOnClickListener {
            val intent = Intent(this, Chapter::class.java)
            startActivity(intent)
        }

        //Assignments button
        assignmentButton.setOnClickListener {
            val intent = Intent(this, Assignments::class.java)
            startActivity(intent)
        }

        //quiz button
        quizButton.setOnClickListener {
            val intent = Intent(this, Quiz::class.java)
            startActivity(intent)
        }
    }
}